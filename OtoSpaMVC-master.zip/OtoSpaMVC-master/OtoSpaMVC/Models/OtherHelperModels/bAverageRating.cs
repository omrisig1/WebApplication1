﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OtoSpaMVC.Models
{
    public class bAverageRating
    {
        public int productID { get; set; }
        public Double AvgRate { get; set; }
    }
}
