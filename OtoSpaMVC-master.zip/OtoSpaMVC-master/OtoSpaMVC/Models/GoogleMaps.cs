﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OtoSpaMVC.Models
{
    public class GoogleMap
    {
        public int ID { get; set; }
        public double langi { get; set; }

        public double longi { get; set; }

    }
}
